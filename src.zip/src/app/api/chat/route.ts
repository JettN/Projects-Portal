import { NextRequest, NextResponse } from "next/server";

export async function POST(request: NextRequest) {
  try {
    const { messages } = await request.json();

    if (!messages || !Array.isArray(messages)) {
      return NextResponse.json({ error: "Messages array required" }, { status: 400 });
    }

    const provider = process.env.LLM_PROVIDER || "gemini";

    let reply = "";

    if (provider === "claude") {
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": process.env.CLAUDE_API_KEY!,
          "anthropic-version": "2023-06-01",
        },
        body: JSON.stringify({
          model: "claude-3-haiku-20240307",
          max_tokens: 1024,
          system: `You are Ramsey, the friendly AI assistant for HKN at UCSD (Honors to Eta Kappa Nu). 
You help students learn about HKN projects, events, how to join, and engineering resources.
Be concise, friendly, and helpful. If you don't know something specific, be honest and suggest 
they email hkn@ucsd.edu.`,
          messages,
        }),
      });
      const data = await response.json();
      reply = data.content?.[0]?.text ?? "Sorry, I couldn't get a response.";

    } else if (provider === "gemini") {
      const lastMessage = messages[messages.length - 1].content;
      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${process.env.GEMINI_API_KEY}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contents: [{ parts: [{ text: lastMessage }] }],
          }),
        }
      );
      const data = await response.json();
      reply = data.candidates?.[0]?.content?.parts?.[0]?.text ?? "Sorry, I couldn't get a response.";

    } else if (provider === "openai") {
      const response = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
        },
        body: JSON.stringify({
          model: "gpt-4o-mini",
          messages: [
            {
              role: "system",
              content: `You are Ramsey, the friendly AI assistant for HKN at UCSD.`,
            },
            ...messages,
          ],
        }),
      });
      const data = await response.json();
      reply = data.choices?.[0]?.message?.content ?? "Sorry, I couldn't get a response.";
    }

    return NextResponse.json({ reply });
  } catch (error: any) {
    console.error("Chat API error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}