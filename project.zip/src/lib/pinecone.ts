import { Pinecone } from "@pinecone-database/pinecone";
import { GoogleGenerativeAI } from "@google/generative-ai";

// ── Initialise clients ────────────────────────────────────────────────────────

const pinecone = new Pinecone({
  apiKey: process.env.PINECONE_API_KEY!,
});

const INDEX_NAME = process.env.PINECONE_INDEX;

// We use Gemini's embedding model to turn the user's query into a vector.
// This MUST be the same model used when indexing — both use "embedding-001"
// so they produce vectors in the same 768-dimensional space.
const embedder = new GoogleGenerativeAI(process.env.GEMINI_API_KEY!);

// ── Main export ───────────────────────────────────────────────────────────────

/**
 * Given a user query, fetch the most relevant chunks from Pinecone
 * and return them as a single string ready to paste into the system prompt.
 *
 * @param query   The user's latest message
 * @param topK    How many chunks to retrieve (3 is a good default)
 */
export async function retrieveContext(query: string, topK = 3): Promise<string> {
  try {
    // 1. Embed the query
    const model = embedder.getGenerativeModel({ model: "text-embedding-004" });
    const result = await model.embedContent(query);
    const queryVector = result.embedding.values;

    // 2. Query Pinecone for the nearest neighbours
    const index = pinecone.index(INDEX_NAME);
    const queryResponse = await index.query({
      vector: queryVector,
      topK,
      includeMetadata: true,
    });

    // 3. Pull the raw text out of each match and join into one block
    const chunks = queryResponse.matches
      .filter((m) => m.score && m.score > 0.5) // ignore low-confidence matches
      .map((m) => {
        const source = m.metadata?.source ?? "unknown";
        const text   = m.metadata?.text   ?? "";
        return `[${source}]\n${text}`;
      });

    if (chunks.length === 0) return "";

    return chunks.join("\n\n---\n\n");

  } catch (err) {
    // If Pinecone is unreachable, fall back gracefully — Ramsey still works,
    // just without the extra knowledge base context.
    console.error("[pinecone] retrieval error:", err);
    return "";
  }
}